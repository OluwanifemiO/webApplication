/**
 * File Name: OOfacade.js
 *
 * Revision History:
 *       Oluwanifemi Ogidama, 2023-02-20 : Created
 */

function showOverallRating() {
    let quality = parseInt($("#txtQuality").val());
    let service = parseInt($("#txtService").val());
    let value = parseInt($("#txtValue").val());

    let ovlRating = getOverallRating(quality, service, value);
    $("#txtRatings").val(ovlRating + "%");
}

function showModifiedOverallRating() {
    let modifyQuality = parseInt($("#txtModifyQuality").val());
    let modifyService = parseInt($("#txtModifyService").val());
    let modifyValue = parseInt($("#txtModifyValue").val());

    let ovlRating = getModifiedOverallRating(modifyQuality, modifyService, modifyValue);
    $("#txtModifyRatings").val(ovlRating + "%");
}

let feedbackAdded = false;

function addFeedback() {
    if (feedbackAdded) {
        console.log("Feedback has already been added");
        return;
    }
    feedbackAdded = true;

    if (validateAddForm()) {
        console.log("Add Form is valid");
        let businessName = $("#txtBusinessName").val();
        let typeId = $("#cmbType").val();
        let reviewerEmail = $("#txtReviewerEmail").val();
        let reviewerComments = $("#txtReviewerComments").val();
        let reviewDate = $("#dateReview").val();
        let hasRating = $("#chkRatings").is(':checked');
        let rating1 = $("#txtQuality").val();
        let rating2 = $("#txtService").val();
        let rating3 = $("#txtValue").val();

        let opt = [businessName, typeId, reviewerEmail, reviewerComments, reviewDate, hasRating, rating1, rating2, rating3];

        function success() {
            alert("Feedback saved successfully.");
        }

        Review.insert(opt, success);

    } else {
        console.error("Add Form is invalid");
    }
}

let feedbackUpdated = false;

function updateFeedback() {
    if (feedbackUpdated) {
        console.log("Feedback has already been updated");
        return;
    }
    feedbackUpdated = true;

    if (validateModifyForm()) {
        console.log("Modify Form is valid");
        let modBusinessName = $("#txtModifyName").val();
        let modTypeId = $("#cmbModifyType").val();
        let modReviewerEmail = $("#txtModifyEmail").val();
        let modReviewerComments = $("#txtModifyComments").val();
        let modReviewDate = $("#dateModifyReview").val();
        let modHasRating = $("#chkModifyRatings").val();
        let modRating1 = $("#txtModifyQuality").val();
        let modRating2 = $("#txtModifyService").val();
        let modRating3 = $("#txtModifyValue").val();
        let id = localStorage.getItem("id");

        let opt = [modBusinessName, modTypeId, modReviewerEmail, modReviewerComments, modReviewDate, modHasRating, modRating1, modRating2, modRating3, id];

        function success() {
            alert("Feedback updated successfully.");
        }

        Review.update(opt, success);
    } else {
        console.error("Modify Form is invalid");
    }
}

let feedbackDeleted = false;

function deleteFeedback() {
    if (feedbackDeleted) {
        console.log("Feedback has already been deleted");
        return;
    }
    feedbackDeleted= true;

    let id = localStorage.getItem("id");

    let options = [id];

    function callback() {
        alert("Feedback deleted successfully");
        $(location).prop('href', "#OOViewFeedbackPage");
    }

    Review.delete(options, callback);
}


function updateTypesDropdown() {
    let options = [];

    function callback(tx, results) {

        let htmlCode = "";

        for (var i = 0; i < results.rows.length; i++) {
            let row = results.rows[i];
            htmlCode += `<option value="${row['id']}">${row['name']}</option>`
        }

        let combobox = $("#cmbType");
        combobox = combobox.html(htmlCode);
        combobox.val('1').change();

        let comboboxMod = $("#cmbModifyType");
        comboboxMod = comboboxMod.html(htmlCode);

    }

    Type.selectAll(options, callback);
}


function getReviews() {
    let options = [];

    function callback(tx, results) {
        let htmlCode = '';

        if (results.rows.length === 0) {
            htmlCode += '<h4>No records found</h4>';
        } else {
            for (var i = 0; i < results.rows.length; i++) {
                let row = results.rows[i];
                htmlCode += `<li>
                    <a data-role="button" data-row-id=${row['id']} href="#OOModifyFeedbackPage">
                    <h4>Business Name: ${row['businessName']}</h4>
                    <p>Reviewer Email: ${row['reviewerEmail']}</p>
                    <p>Reviewer Comments: ${row['reviewerComments']}</p>
                    <p>Overall Rating: ${getOverallRating(row.rating1, row.rating2, row.rating3) + "%"}</p>
                    </a>
                    </li>`
            }
        }
        let lv = $("#lstViewFeedback");
        lv = lv.html(htmlCode);
        lv.listview('refresh'); //very important


        function linkClickHandler() {
            console.log($(this).attr("data-row-id"));
            localStorage.setItem("id", $(this).attr("data-row-id"));
            $(location).prop("href", "#OOModifyFeedbackPage");
        }

        $("#lstViewFeedback a").on("click", linkClickHandler);
    }

    Review.selectAll(options, callback);
}

function showCurrentReview() {
    let id = localStorage.getItem("id");
    let options = [id];
    function callback(tx, results) {
        console.log(results.rows.length);
        let review = results.rows[0];

        // populate the form with the retrieved data
        $("#txtModifyName").val(review['businessName']);
        $("#cmbModifyType").val(review.typeId).change();
        $("#cmbModifyType").selectmenu();
        $("#cmbModifyType").selectmenu("refresh");
        $("#txtModifyEmail").val(review.reviewerEmail);
        $("#txtModifyComments").val(review.reviewerComments);
        $("#dateModifyReview").val(review.reviewDate);

        if (review.hasRating == "true") {
            $("#chkModifyRatings").prop("checked", true).change();
            $("#chkModifyRatings").checkboxradio();
            $("#chkModifyRatings").checkboxradio("refresh");
            $("#divModifyRatings").show();
            $("#txtModifyQuality").val(review.rating1);
            $("#txtModifyService").val(review.rating2);
            $("#txtModifyValue").val(review.rating3);
            $("#txtModifyRatings").val(getOverallRating(review.rating1, review.rating2, review.rating3) + "%");
        } else {
            $("#chkModifyRatings").prop("checked", false).change();
            $("#chkModifyRatings").checkboxradio();
            $("#chkModifyRatings").checkboxradio("refresh");
            $("#divModifyRatings").hide();
            $("#txtModifyQuality").val(0);
            $("#txtModifyService").val(0);
            $("#txtModifyValue").val(0);
        }
    }


    Review.select(options, callback);
}

function backToPreviousPage(){
    $(location).prop("href", "#OOViewFeedbackPage");

}

let databaseCleared = false;

function clearDatabase() {
    if (databaseCleared) {
        console.log("Database has been cleared");
        return;
    }
    databaseCleared = true;

    let result = confirm("Really want to clear database?");
    if (result) {
        try {
            DB.dropTables();
            alert("Database cleared: All tables dropped");
        } catch (e) {
            alert(e);
        }
    }
}











