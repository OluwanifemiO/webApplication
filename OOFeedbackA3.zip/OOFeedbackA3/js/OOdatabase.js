/**
 * File Name: OOdatabase.js
 *
 * Revision History:
 *       Oluwanifemi Ogidama, 2023-02-20 : Created
 */

function saveEmail()
{
    localStorage.setItem("DefaultEmail", `${$("#txtDefaultEmail").val()}`);
    alert("Default reviewer email saved.");
}

var db;

function errorHandler(error){
    console.log('error caught: ', error)
    console.error(`Error: ${error.message}`);
}

var DB={
    createDatabase:function(){
        let name = "OOFeedback3DB";
        let version = "2.0";
        let displayName = "DB for OOFeedback3 App";
        let size = 2*1024*1024;

        function createCallback(){
            console.log("Success! Database created successfully");
        }

        db = openDatabase(name, version, displayName, size, createCallback);
    },

    createTables:function(){
        try {
            function txFunction(tx) {
                // Check if the 'type' table exists
                tx.executeSql("SELECT name FROM sqlite_master WHERE type='table' AND name='type';", [], function(tx, result) {
                    if (result.rows.length === 0) {
                        // 'type' table does not exist, create it
                        let sql2 = "CREATE TABLE type( " +
                            "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                            "name VARCHAR(20) NOT NULL);"

                        tx.executeSql(sql2, [], function() {
                            console.log("Success! Table created successfully");
                        }, errorHandler);

                        // Insert default values
                        tx.executeSql("INSERT INTO type (name) VALUES ('Others'), ('Canadian'), ('Asian'), ('European'), ('Australian');", [], null, errorHandler);
                    } else {
                        console.log("Table 'type' already exists");
                    }
                });

                // Create the 'review' table
                let sql4 = "CREATE TABLE IF NOT EXISTS review( " +
                    "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                    "businessName VARCHAR(30) NOT NULL," +
                    "typeId INTEGER NOT NULL," +
                    "reviewerEmail VARCHAR(30)," +
                    "reviewerComments TEXT," +
                    "reviewDate DATE," +
                    "hasRating VARCHAR(1)," +
                    "rating1 INTEGER," +
                    "rating2 INTEGER," +
                    "rating3 INTEGER," +
                    "FOREIGN KEY(typeId) REFERENCES type(id));";

                tx.executeSql(sql4, [], function() {
                    console.log("Success! Table created successfully");
                }, errorHandler);
            }

            function successTransaction() {
                console.log("Success! Table creation transaction successful");
            }

            db.transaction(txFunction, errorHandler, successTransaction);

        }
        catch(error){
            console.error(error);
        }
    },
    dropTables:function(){
        function txFunction(tx){
            var sql = "DROP TABLE IF EXISTS type;"
            var sql2 = "DROP TABLE IF EXISTS review";

            let options = [];
            function successCallback(){
                console.log("Success! Tables dropped successfully");
            }

            tx.executeSql(sql, options, successCallback, errorHandler);
            tx.executeSql(sql2, options, successCallback, errorHandler);
        }
            function successTransaction(){
                console.log("Success! Tables drop transaction successful");
            }

            db.transaction(txFunction, errorHandler,successTransaction);


    }
}
