/**
 * File Name: OOglobal.js
 *
 * Revision History:
 *       Oluwanifemi Ogidama, 2023-02-20 : Created
 */
function checkStatus(){
    if($(this).is(':checked'))
    {
        $('#div').show();
        $('#txtQuality').val('0');
        $('#txtService').val('0');
        $('#txtValue').val('0');
    }
    else{
        $('#div').hide();
    }
}


function checkModifyStatus() {
    if($(this).is(':checked'))
    {
        $('#div1').show();
        $('#txtModifyQuality').val('0');
        $('#txtModifyService').val('0');
        $('#txtValue').val('0');
    }
    else{
        $('#div1').hide();
    }
}

function totalRating() {
    showOverallRating();
    showModifiedOverallRating();
}

function btnSave_click() {
    addFeedback();
}

function btnUpdate_click() {
    updateFeedback();
}


function btnSaveDefault_click() {
    saveEmail();
}

function btnDelete_click() {
    deleteFeedback();
}

function AddPageShow() {
    var email = localStorage.getItem("DefaultEmail");
    $("#txtReviewerEmail").val(email);
    updateTypesDropdown();
}

function btnClearDatabase_click() {
    clearDatabase();
}

function ReviewPageShow() {
    getReviews();
}

function ModifyPageShow() {
    showCurrentReview();
}

function btnCancel_click() {
    backToPreviousPage();
}

function init(){
    $('#chkRatings').change(checkStatus);
    $('#txtQuality').change(totalRating);
    $('#txtService').change(totalRating);
    $('#txtValue').change(totalRating);
    $("#OOAddFeedbackPage").on("pageshow", AddPageShow);
    $("#OOViewFeedbackPage").on("pageshow", ReviewPageShow);
    $("#OOModifyFeedbackPage").on("pageshow", ModifyPageShow);

    // Modify form
    $('#chkModifyRatings').change(checkModifyStatus);
    $('#txtModifyQuality').change(totalRating);
    $('#txtModifyService').change(totalRating);
    $('#txtModifyValue').change(totalRating);

    $("#btnSave").click(btnSave_click);
    $("#btnUpdate").click(btnUpdate_click);
    $("#btnSaveDefault").click(btnSaveDefault_click);
    $("#btnDelete").click(btnDelete_click);
    $("#btnClearDatabase").click(btnClearDatabase_click);
    $("#btnCancel").click(btnCancel_click);

}
$(document).ready(function () {
    init();
});


function initDB(){
    try {
        DB.createDatabase();
        if (db) {

            DB.createTables(function(){

            });
            showCurrentReview();
        }
        else{
            console.error("Error in creating tables");
        }
    } catch (e) {
        console.error("Error: (Fatal) error in initDB. Can not proceed");
    }
}

$(document).ready(function () {
    init();
    initDB();
});




