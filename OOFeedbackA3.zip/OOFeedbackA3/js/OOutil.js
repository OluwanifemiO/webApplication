/**
 * File Name: OOutil.js
 *
 * Revision History:
 *       Oluwanifemi Ogidama, 2023-02-20 : Created
 */

function getOverallRating(quality, service, value){
    let ovlRating = (quality + service + value) * 6.66666667 ;
      return Math.round(ovlRating);
}

function getModifiedOverallRating(modifyQuality, modifyService, modifyValue){
    let modifyOvlRating = (modifyQuality + modifyService + modifyValue) * 6.66666667 ;
    return Math.round(modifyOvlRating);
}


function validateAddForm(){
    let form = $("#frmAdd");
    form.validate({
        rules:{
            txtBusinessName:{
                required: true,
                minlength: 2,
                maxlength: 20
            },
            txtReviewerEmail:{
                required: true,
                emailcheck: true
            },
            dateReview:{
                required: true,
            },
            txtQuality:{
                required: "#chkRatings:checked",
                chkboxcheck1: true
            },
            txtService:{
                required: "#chkRatings:checked",
                chkboxcheck1: true
            },
            txtValue:{
                required: "#chkRatings:checked",
                chkboxcheck1: true
            }
        },
        messages:{
            txtBusinessName:{
                required: "Please enter the business name",
                minlength: "Length must be between 2-20 characters long",
                maxlength: "Length must be between 2-20 characters long"
            },
            txtReviewerEmail:{
                required: "Reviewer email is required",
                modifyemailcheck: "Email entered is invalid"
            },
            dateReview:{
                required: "Review date is required"
            },
            txtQuality:{
                chkboxcheck1: "Value must be between 0 and 5"
            },
            txtService:{
                chkboxcheck1: "Value must be between 0 and 5"
            },
            txtValue:{
                chkboxcheck1: "Value must be between 0 and 5"
            }
        }
    });
    return form.valid();
}

function validateModifyForm()
{
    let form = $("#frmModify");
    form.validate({
        rules:{
            txtModifyName:{
                required: true,
                minlength: 2,
                maxlength: 20
            },
            txtModifyEmail:{
                required: true,
                modifyemailcheck: true
            },
            dateModifyReview:{
                required: true,
            },
            txtModifyQuality:{
                required: "#chkModifyRatings:checked",
                chkboxcheck2: true
            },
            txtModifyService:{
                required: "#chkModifyRatings:checked",
                chkboxcheck2: true
            },
            txtModifyValue:{
                required: "#chkModifyRatings:checked",
                chkboxcheck2: true
            }
        },
        messages:{
            txtModifyName:{
                required: "Please enter the business name",
                minlength: "Length must be between 2-20 characters long",
                maxlength: "Length must be between 2-20 characters long"
            },
            txtModifyEmail:{
                required: "Reviewer email is required",
                modifyemailcheck: "Email entered is invalid"
            },
            dateModifyReview:{
                required: "Review date is required"
            },
            txtModifyQuality:{
                chkboxcheck2: "Value must be between 0 and 5"
            },
            txtModifyService:{
                chkboxcheck2: "Value must be between 0 and 5"
            },
            txtModifyValue:{
                chkboxcheck2: "Value must be between 0 and 5"
            }
        }
    });
    return form.valid();
}

jQuery.validator.addMethod("chkboxcheck1", function(value, element){
    let min = 0;
    let max = 5;

    // Convert the input value to a number
    let input = parseFloat(value);

    // Check if the input value falls within 0
    return this.optional(element) || (input >= min && input <= max);
}, "Value must be between 0 and 5");

jQuery.validator.addMethod("chkboxcheck2", function(value, element){
    let min = 0;
    let max = 5;

    // Convert the input value to a number
    let input = parseFloat(value);

    // Check if the input value falls within the specified range
    return this.optional(element) || (input >= min && input <= max);
}, "Value must be between 0 and 5");

jQuery.validator.addMethod("modifyemailcheck", function(value, element){
    return this.optional(element) || /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(value);
}, "Email entered is invalid");

jQuery.validator.addMethod("emailcheck", function(value, element){
    return this.optional(element) || /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(value);
}, "Email entered is invalid");